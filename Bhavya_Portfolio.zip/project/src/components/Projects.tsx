import React, { useState } from 'react';
import { X } from 'lucide-react';

interface Project {
  title: string;
  description: string;
  achievements: string[];
  technologies: string[];
  image: string;
}

const ProjectModal = ({
  project,
  onClose,
}: {
  project: Project;
  onClose: () => void;
}) => {
  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="glass-effect rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-2xl font-bold text-gray-200">{project.title}</h3>
            <button
              onClick={onClose}
              className="p-1 hover:bg-white/10 rounded-full transition-colors"
            >
              <X className="w-6 h-6 text-gray-300" />
            </button>
          </div>
          
          <img
            src={project.image}
            alt={project.title}
            className="w-full h-48 object-cover rounded-lg mb-4"
          />
          
          <p className="text-gray-300 mb-4">{project.description}</p>
          
          <h4 className="font-semibold text-gray-200 mb-2">Key Achievements:</h4>
          <ul className="list-disc list-inside mb-4 text-gray-300">
            {project.achievements.map((achievement, index) => (
              <li key={index}>{achievement}</li>
            ))}
          </ul>
          
          <h4 className="font-semibold text-gray-200 mb-2">Technologies Used:</h4>
          <div className="flex flex-wrap gap-2">
            {project.technologies.map((tech, index) => (
              <span
                key={index}
                className="px-3 py-1 bg-purple-500/20 text-purple-300 rounded-full text-sm"
              >
                {tech}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

const ProjectCard = ({
  project,
  onClick,
}: {
  project: Project;
  onClick: () => void;
}) => {
  return (
    <div
      className="glass-effect rounded-lg overflow-hidden cursor-pointer transform transition-all duration-300 
      hover:-translate-y-2 hover:shadow-lg hover:shadow-purple-500/10"
      onClick={onClick}
    >
      <img
        src={project.image}
        alt={project.title}
        className="w-full h-48 object-cover"
      />
      <div className="p-6">
        <h3 className="text-xl font-semibold text-gray-200 mb-2">
          {project.title}
        </h3>
        <p className="text-gray-300 mb-4">{project.description}</p>
        <div className="flex flex-wrap gap-2">
          {project.technologies.slice(0, 3).map((tech, index) => (
            <span
              key={index}
              className="px-3 py-1 bg-purple-500/20 text-purple-300 rounded-full text-sm"
            >
              {tech}
            </span>
          ))}
          {project.technologies.length > 3 && (
            <span className="px-3 py-1 bg-white/5 text-gray-400 rounded-full text-sm">
              +{project.technologies.length - 3} more
            </span>
          )}
        </div>
      </div>
    </div>
  );
};

const Projects = () => {
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);

  const projects: Project[] = [
    {
      title: 'YouStock',
      description: 'Advanced trading strategy platform using sentiment analysis and machine learning',
      achievements: [
        'Developed trading strategies using sentiment analysis, boosting precision by 10%',
        'Reduced latency by 27% with improved backtesting',
        'Implemented real-time market data processing pipeline',
      ],
      technologies: ['Python', 'TensorFlow', 'NLP', 'Time Series Analysis', 'AWS'],
      image: 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?auto=format&fit=crop&w=800&q=80',
    },
    {
      title: 'Abstractive Gen AI Q&A Bot',
      description: 'Intelligent Q&A system using advanced language models and vector storage',
      achievements: [
        'Created Q&A bot using ELI5 BART, improving answer accuracy by 30%',
        'Integrated Pinecone for vector storage, enhancing retrieval efficiency',
        'Implemented context-aware response generation',
      ],
      technologies: ['PyTorch', 'Hugging Face', 'FastAPI', 'Pinecone', 'Docker'],
      image: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?auto=format&fit=crop&w=800&q=80',
    },
    {
      title: 'Project Narmadae',
      description: 'Water leak detection and demand forecasting system',
      achievements: [
        'Achieved 84% F1 score in water leak detection',
        'Forecasted water demand with 89% accuracy using PyCaret',
        'Implemented real-time monitoring system',
      ],
      technologies: ['Python', 'PyCaret', 'Scikit-learn', 'Time Series Analysis', 'IoT'],
      image: 'https://images.unsplash.com/photo-1436262513933-a0b06755c784?auto=format&fit=crop&w=800&q=80',
    },
    {
      title: 'Delivery Rider Estimation',
      description: 'ML-powered system for optimizing rider availability prediction',
      achievements: [
        'Built model using XGBoost to predict rider availability',
        'Improved operational efficiency during peak hours',
        'Implemented real-time prediction API',
      ],
      technologies: ['Python', 'XGBoost', 'FastAPI', 'PostgreSQL', 'Docker'],
      image: 'https://images.unsplash.com/photo-1526367790999-0150786686a2?auto=format&fit=crop&w=800&q=80',
    },
  ];

  return (
    <section id="projects" className="py-20 bg-background relative">
      <div className="absolute inset-0 hexagon-bg opacity-10"></div>
      <div className="container mx-auto px-4 relative z-10">
        <h2 className="section-title">Featured Projects</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {projects.map((project, index) => (
            <ProjectCard
              key={index}
              project={project}
              onClick={() => setSelectedProject(project)}
            />
          ))}
        </div>
      </div>

      {selectedProject && (
        <ProjectModal
          project={selectedProject}
          onClose={() => setSelectedProject(null)}
        />
      )}
    </section>
  );
};

export default Projects;