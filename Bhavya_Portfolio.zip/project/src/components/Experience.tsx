import React from 'react';
import { Calendar, Briefcase } from 'lucide-react';

interface ExperienceItem {
  title: string;
  company: string;
  period: string;
  achievements: string[];
}

const ExperienceCard = ({ experience }: { experience: ExperienceItem }) => {
  return (
    <div className="glass-effect p-6 rounded-lg hover:shadow-lg hover:shadow-purple-500/10 transition-all duration-300 transform hover:-translate-y-1">
      <h3 className="text-xl font-semibold text-gray-200 mb-2">{experience.title}</h3>
      <div className="flex items-center text-gray-400 mb-4">
        <Briefcase className="w-4 h-4 mr-2" />
        <span>{experience.company}</span>
        <Calendar className="w-4 h-4 ml-4 mr-2" />
        <span>{experience.period}</span>
      </div>
      <ul className="space-y-2">
        {experience.achievements.map((achievement, index) => (
          <li key={index} className="flex items-start">
            <span className="text-purple-400 mr-2">•</span>
            <span className="text-gray-300">{achievement}</span>
          </li>
        ))}
      </ul>
    </div>
  );
};

const Experience = () => {
  const experiences: ExperienceItem[] = [
    {
      title: 'Artificial Intelligence Intern',
      company: 'FoodNEST(S)',
      period: 'Sept 2024 – Nov 2024',
      achievements: [
        'Developed a multilingual, multimodal AI chatbot supporting 22+ Indic languages, reducing manual workload by 40%',
        'Designed web, map, and video scrapers, hosted on AWS EC2 using Gunicorn and Docker for scalability',
      ],
    },
    {
      title: 'AI Development Intern',
      company: 'Seequenze Technologies',
      period: 'Nov 2024 – Present',
      achievements: [
        'Built an end-to-end OCR detector for a truck registration pipeline',
        'Prompt-engineered LLMs to refactor 10,000+ lines of code while handling edge cases',
        'Designed production-ready backend using FastAPI to cater to 1,000+ business clients',
      ],
    },
    {
      title: 'Artificial Intelligence Engineer',
      company: 'Radical X',
      period: 'July 2024 – Sept 2024',
      achievements: [
        'Collaborated on hackathons using OpenAI, VertexAI, and TensorFlow',
        'Developed personalized career guidance solutions using AI',
      ],
    },
    {
      title: 'Software Engineering Fellow',
      company: 'Headstarter AI',
      period: 'Nov 2023 – Feb 2024',
      achievements: [
        'Built enterprise AI projects including multimodal voice assistant',
        'Developed music AI with visual generation capabilities',
      ],
    },
  ];

  return (
    <section id="experience" className="py-20 bg-muted relative">
      <div className="absolute inset-0 hexagon-bg opacity-10"></div>
      <div className="container mx-auto px-4 relative z-10">
        <h2 className="section-title">Professional Experience</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {experiences.map((exp, index) => (
            <ExperienceCard key={index} experience={exp} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Experience;