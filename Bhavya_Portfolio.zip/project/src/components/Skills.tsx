import React from 'react';

const SkillBar = ({ skill, percentage }: { skill: string; percentage: number }) => {
  return (
    <div className="mb-4">
      <div className="flex justify-between mb-1">
        <span className="text-gray-300">{skill}</span>
        <span className="text-gray-400">{percentage}%</span>
      </div>
      <div className="w-full bg-gray-800 rounded-full h-2.5">
        <div
          className="bg-gradient-to-r from-purple-500 to-pink-500 h-2.5 rounded-full transition-all duration-1000"
          style={{ width: `${percentage}%` }}
        ></div>
      </div>
    </div>
  );
};

const SkillCategory = ({ title, skills }: { title: string; skills: { name: string; level: number }[] }) => {
  return (
    <div className="glass-effect p-6 rounded-lg hover:shadow-lg hover:shadow-purple-500/10 transition-all duration-300">
      <h3 className="text-xl font-semibold mb-4 text-gray-200">{title}</h3>
      <div className="space-y-4">
        {skills.map((skill) => (
          <SkillBar key={skill.name} skill={skill.name} percentage={skill.level} />
        ))}
      </div>
    </div>
  );
};

const Skills = () => {
  const skillCategories = [
    {
      title: 'Languages',
      skills: [
        { name: 'Python', level: 95 },
        { name: 'C++', level: 85 },
        { name: 'JavaScript', level: 80 },
        { name: 'SQL', level: 85 },
      ],
    },
    {
      title: 'Developer Tools',
      skills: [
        { name: 'TensorFlow', level: 90 },
        { name: 'PyTorch', level: 85 },
        { name: 'Docker', level: 80 },
        { name: 'AWS/GCP', level: 75 },
      ],
    },
    {
      title: 'Techniques & Concepts',
      skills: [
        { name: 'Deep Learning', level: 90 },
        { name: 'NLP', level: 85 },
        { name: 'LLM Fine-tuning', level: 80 },
        { name: 'Computer Vision', level: 85 },
      ],
    },
    {
      title: 'Data Science Libraries',
      skills: [
        { name: 'NumPy/Pandas', level: 95 },
        { name: 'Scikit-learn', level: 90 },
        { name: 'Matplotlib/Seaborn', level: 85 },
        { name: 'Hugging Face', level: 80 },
      ],
    },
  ];

  return (
    <section id="skills" className="py-20 bg-background relative">
      <div className="absolute inset-0 hexagon-bg opacity-10"></div>
      <div className="container mx-auto px-4 relative z-10">
        <h2 className="section-title">Technical Skills</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {skillCategories.map((category) => (
            <SkillCategory
              key={category.title}
              title={category.title}
              skills={category.skills}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Skills;