import React from 'react';
import { Container } from './ui/Container';

const About = () => {
  return (
    <section id="about" className="py-20 bg-muted relative">
      <div className="absolute inset-0 hexagon-bg opacity-10"></div>
      
      <Container className="relative z-10">
        <h2 className="section-title">About Me</h2>
        
        <div className="flex flex-col md:flex-row items-center gap-12">
          <div className="w-full md:w-1/3">
            <div className="relative group">
              <div className="absolute -inset-2 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg blur opacity-25 
                group-hover:opacity-75 transition duration-1000 group-hover:duration-200">
              </div>
              <div className="relative aspect-square overflow-hidden rounded-lg">
                <img
                  src="https://i.ibb.co/CzGXfWT/Whats-App-Image-2024-12-24-at-11-19-29-a340075f.jpg"
                  alt="Bhavya Pratap Singh Tomar"
                  className="w-full h-full object-cover transform transition duration-500 group-hover:scale-110"
                />
                {/* <a href="https://ibb.co/CzGXfWT"><img src="https://i.ibb.co/CzGXfWT/Whats-App-Image-2024-12-24-at-11-19-29-a340075f.jpg" alt="Whats-App-Image-2024-12-24-at-11-19-29-a340075f" border="0"></a> */}
              </div>
            </div>
          </div>
          
          <div className="w-full md:w-2/3">
            <div className="glass-effect p-8 rounded-lg">
              <p className="text-gray-300 text-lg mb-6 leading-relaxed">
                I am a dedicated Artificial Intelligence and Machine Learning professional with hands-on experience in building 
                scalable AI solutions, optimizing ML models, and integrating cutting-edge technologies for real-world impact.
              </p>
              
              <div className="space-y-6">
                <div className="flex flex-col md:flex-row md:items-start gap-4">
                  <div className="font-semibold text-purple-400 md:w-32">Education:</div>
                  <div className="text-gray-300">
                    Bachelor of Technology in AI & ML
                    <br />
                    <span className="text-gray-400">Madhav Institute of Technology and Science</span>
                  </div>
                </div>
                
                <div className="flex flex-col md:flex-row md:items-start gap-4">
                  <div className="font-semibold text-purple-400 md:w-32">Focus Areas:</div>
                  <div className="text-gray-300">
                    <ul className="space-y-2">
                      <li className="flex items-center">
                        <span className="w-2 h-2 bg-purple-500 rounded-full mr-2"></span>
                        Artificial Intelligence & Machine Learning
                      </li>
                      <li className="flex items-center">
                        <span className="w-2 h-2 bg-purple-500 rounded-full mr-2"></span>
                        Generative AI & LLM Engineering
                      </li>
                      <li className="flex items-center">
                        <span className="w-2 h-2 bg-purple-500 rounded-full mr-2"></span>
                        Backend Development
                      </li>
                      <li className="flex items-center">
                        <span className="w-2 h-2 bg-purple-500 rounded-full mr-2"></span>
                        Deep Learning & Computer Vision
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Container>
    </section>
  );
};

export default About;