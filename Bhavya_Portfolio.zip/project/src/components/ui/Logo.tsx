import React from 'react';
import { Brain } from 'lucide-react';

export const Logo = () => {
  return (
    <div className="relative group">
      {/* Neural network background effect */}
      <div className="absolute -inset-1 bg-gradient-to-r from-purple-600/50 to-pink-600/50 rounded-lg blur opacity-25 
        group-hover:opacity-75 transition duration-1000 group-hover:duration-200">
      </div>
      
      {/* Logo container */}
      <div className="relative flex items-center space-x-2">
        <div className="p-2 rounded-lg bg-gradient-to-r from-purple-500 to-pink-500">
          <Brain className="w-6 h-6 text-white animate-pulse" />
        </div>
        <span className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-pink-500 text-transparent bg-clip-text
          group-hover:from-purple-500 group-hover:to-pink-600 transition-all duration-300">
          BPST
        </span>
      </div>
    </div>
  );
};