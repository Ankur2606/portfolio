import React from 'react';
import { ChevronDown } from 'lucide-react';
import { Container } from './ui/Container';

const Hero = () => {
  return (
    <section id="home" className="min-h-screen relative overflow-hidden bg-background flex items-center">
      {/* Background Effects */}
      <div className="absolute inset-0 hexagon-bg opacity-20"></div>
      <div className="absolute inset-0 bg-gradient-to-b from-purple-500/5 to-transparent"></div>
      
      <Container className="relative z-10">
        <div className="text-center max-w-4xl mx-auto">
          <h1 className="text-5xl md:text-7xl font-bold mb-6 bg-gradient-to-r from-purple-400 to-pink-500 text-transparent bg-clip-text animate-gradient">
            Bhavya Pratap Singh Tomar
          </h1>
          <p className="text-xl md:text-2xl text-gray-300 mb-8">
            AI/ML Developer | Innovator | Problem-Solver
          </p>
          <p className="text-lg md:text-xl text-gray-400 mb-12 max-w-2xl mx-auto">
            Engineering intelligent solutions to transform industries
          </p>
          <div className="flex flex-col md:flex-row justify-center gap-4">
            <a
              href="#projects"
              className="px-8 py-3 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-lg 
              hover:from-purple-600 hover:to-pink-600 transition-all duration-300 shadow-lg 
              hover:shadow-purple-500/25"
            >
              Explore Portfolio
            </a>
            <a
              href="#contact"
              className="px-8 py-3 glass-effect text-gray-200 rounded-lg hover:bg-white/10 
              transition-all duration-300"
            >
              Contact Me
            </a>
          </div>
        </div>
      </Container>

      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <ChevronDown className="w-6 h-6 text-gray-400" />
      </div>
    </section>
  );
};

export default Hero;